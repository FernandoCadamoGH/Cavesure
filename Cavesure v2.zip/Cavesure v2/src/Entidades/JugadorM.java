package Entidades;


import static AJugador.AnimJug.jugadora.Correr;
import static AJugador.AnimJug.jugadora.ObAnJug;
import static AJugador.AnimJug.jugadora.Quieto;

import java.awt.Graphics;
import java.awt.image.BufferedImage;


import AJugador.CargaGuardado;

public class JugadorM extends Entidad{
	private BufferedImage[][] anim; // carga de imagen del jugador
    private int acJug = Quieto; //acciones del jugador 
//    private int MiJug = -1; 
    private boolean ArribJ,AbaJ,DerJ,IzqJ;
    private boolean desp=false; //desplazamiento
    private int punto,indice,vel=30; // velocidad de imagen 
    private float velJug = 2.0f;
   
    
	public JugadorM(float x, float y){
		super(x,y);
		Animaciones();
		
	}
	
	public void actua(){
		  PosJug();
	      ActuAnim();
	      animElec();
	}
	
	public void renderizado(Graphics g){
        g.drawImage(anim[acJug][indice], (int) x, (int) y,32,32,null);
	}
    
     

    
    //actualizacion de imagenes del jugador
     private void ActuAnim() {
    	 punto++;
    	 if(punto>=vel){
    		 punto=0;
    		 indice++;
    		 if(indice >= ObAnJug(acJug)){indice=0;}
    	 }
 	}
     
     
     //tipo de accion del jugador
     private void animElec(){
     	if(desp){acJug = Correr;}else{acJug = Quieto;}
     }
     
     private void PosJug(){
    	 desp = false;
    	 //Movimiento Horizontal
    	 if(IzqJ && !DerJ){x-=velJug;desp=true;}else{if(DerJ && !IzqJ){x+=velJug;desp=true;}}
    	 //Movimiento Vertical
    	 if(ArribJ && !AbaJ){y-=velJug;desp=true;}else{if(AbaJ && !ArribJ){y+=velJug;desp=true;}}
    	 
     }
	
	  private void Animaciones() {
				BufferedImage img = CargaGuardado.ObImages(CargaGuardado.SpriteJugM);
				
				anim = new BufferedImage[2][4];
		    	for(int c=0;c<anim.length;c++){
		    		for(int f=0;f<anim[c].length;f++){
		        		anim[c][f] = img.getSubimage(f*16,c*16,16,16);
		        	}
		    	}
		}
	  
	public void reinDirec(){
		ArribJ = false;
		DerJ = false;
		IzqJ = false;
		AbaJ = false;
	}

	public boolean isArribJ() {
		return ArribJ;
	}

	public void setArribJ(boolean arribJ) {
		ArribJ = arribJ;
	}

	public boolean isAbaJ() {
		return AbaJ;
	}

	public void setAbaJ(boolean abaJ) {
		AbaJ = abaJ;
	}

	public boolean isDerJ() {
		return DerJ;
	}

	public void setDerJ(boolean derJ) {
		DerJ = derJ;
	}

	public boolean isIzqJ() {
		return IzqJ;
	}

	public void setIzqJ(boolean izqJ) {
		IzqJ = izqJ;
	}
	  
	  
}
