package Entidades;

public abstract class Entidad {
	
	protected float x,y;
	public Entidad(float x, float y){
		this.x = x;
		this.y = y;
	}

}
