package LogicaComp;
/*
 * En esta clase observamos el uso de los hilos para cada operacion, un hilo es fundamentalmente una
 * forma mejor efectiva para no sobrecargar el hilo principal y para operar diferentes calculos al mismo tiempo
 */
import java.awt.Graphics;

import AdminisNiveles.AgenteNiveles;
import Entidades.JugadorM;

public class Juego implements Runnable{
		private Ventana vent;
		private Panel pan;
		private Thread HiloJuego;
		private final int FPS_xSeg = 120;
		private final int UPS_xSeg = 200; 
		private AgenteNiveles ANlvl;
		
		public final static int Tam_Tile_defect = 16;
		public final static float scla = 2f;
		public final static int Tam_Anch = 26;
		public final static int Tam_Alt = 14;
		public final static int Tam_Tile = (int) (Tam_Tile_defect * scla);
		public final static int Tam_Jueg_Anc = Tam_Tile * Tam_Anch;
		public final static int Tam_Jueg_Alt = Tam_Tile * Tam_Alt;

		
	    private JugadorM JM;
		
		
		    public Juego(){
		    	 iniciarClass();
		    	
		       pan = new Panel(this);
		       vent = new Ventana(pan); 
		       pan.requestFocus();
		      
		       InicioBucleJuego();
		    }

		    private void iniciarClass() {
				JM = new JugadorM(200,200);
				ANlvl = new AgenteNiveles(this);
				
			}

			private void InicioBucleJuego(){
		        HiloJuego = new Thread(this);
		        HiloJuego.start();
		    }
		    
		    public void actualizacion(){
		    	ANlvl.actualiza();
		    	JM.actua();		    	
		    }
		    
		    public void render(Graphics g){
		    	ANlvl.pintado(g);
		    	JM.renderizado(g);		    	
		    }
		    
		    @Override
		    public void run() {
		    	double TPU = 1000000000.0 / UPS_xSeg;	
		        double TPF = 1000000000.0 / FPS_xSeg;
		        
		        long TiemAnterior = System.nanoTime();
		        
		        double Obturador = 0;
		        double AgenteFrames = 0;
		        
		        int actualizaciones = 0;
		        int velImagen = 0;
		        long UltimoRecuento = System.currentTimeMillis();
		        while(true){
		        	
		        	long TiempoActual = System.nanoTime();
		        	
		        	Obturador += (TiempoActual - TiemAnterior) / TPU;
		        	AgenteFrames += (TiempoActual - TiemAnterior) / TPF;
		        	TiemAnterior = TiempoActual;
		        	
		        	if(Obturador >= 1){
		        		actualizacion();
		        		actualizaciones++;
		        		Obturador--;
		        	}
		        	
		        	if(AgenteFrames >= 1){
		        		 pan.repaint();   
			             velImagen++;
			             AgenteFrames--;
		        	}
		        	
		            
		            if(System.currentTimeMillis()- UltimoRecuento >= 1000){
		                UltimoRecuento = System.currentTimeMillis();
		                System.out.println("FPS: "+velImagen+" | UPS: "+actualizaciones);
		                velImagen=0;
		                actualizaciones = 0;
		            }
		        }
		    }
		    
		    public void PerdidaVisu(){
		    	JM.reinDirec();
		    }
		    
		    public JugadorM obCaract(){
		    	return JM;
		    }
}
