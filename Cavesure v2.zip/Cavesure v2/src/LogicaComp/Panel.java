package LogicaComp;

import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JPanel;
import AtajosTeclado.Teclado;
import static LogicaComp.Juego.Tam_Jueg_Alt;
import static LogicaComp.Juego.Tam_Jueg_Anc;



@SuppressWarnings("serial")
public class Panel extends JPanel{
 private Juego Ju;
    public Panel(Juego Ju){
    	this.Ju = Ju;
        TamPanel();
        addKeyListener(new Teclado(this));
    }
	
    
    public void TamPanel(){
        Dimension tam = new Dimension(Tam_Jueg_Anc,Tam_Jueg_Alt);
        setMinimumSize(tam);
        setPreferredSize(tam);
        setMaximumSize(tam);
        System.out.println("Tam = "+Tam_Jueg_Anc+" : "+Tam_Jueg_Alt);
    }
    
    public void actuaJuego(){
     
    }   
                 
    @Override
    public void paint(Graphics g){
        super.paint(g);
        Ju.render(g);
    }
    
    public Juego ObCaJu(){
    	return Ju;
    }

	
   
}

