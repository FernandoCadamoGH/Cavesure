package LogicaComp;


/*
 * Desarrollado en eclipse neon 3 (Software lanzado para el 2017) con java 1.8u222x64
 * Desarrollado por Fernando Cadamo Programacion Unet y David Lozada S1
 * En la creacion de este juego se han presentado problemas tanto en el apartado de rendimiento del SO y hadware
 * se usa como creacion de mapas el metodo RGB donde el color rojo se usa como indice en las texturas para cada nivel desarrollado
 * cada asset fue creado 100% a mano tanto con Aseprite como con PaintToolSai 
 */

import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;

import javax.swing.JFrame;
/*
 * Aca es la presentacion de la ventana principal, su tama�o se observa en 
 */
public class Ventana {


public Ventana(Panel pan){
    JFrame f = new JFrame();
    f.add(pan);
    f.setTitle("Cavesure  -- Adentrate mas a fondo --");
    f.pack();
    f.setLocationRelativeTo(null);
    f.setResizable(false);
    f.setVisible(true);
    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    f.addWindowFocusListener(new WindowFocusListener(){
    	@Override
    	public void windowLostFocus(WindowEvent e){
    		pan.ObCaJu().PerdidaVisu();
    	}
    	
    	@Override
    	public void windowGainedFocus(WindowEvent e){
    		
    	}
    });
}

}

