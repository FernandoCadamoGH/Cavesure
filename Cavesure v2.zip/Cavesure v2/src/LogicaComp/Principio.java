package LogicaComp;

public class Principio {
	 public static void main(String[] args) {
	        new Juego();
	    }
}
