package AtajosTeclado;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import Entidades.JugadorM;

import static AJugador.AnimJug.LadoMira.*;

import LogicaComp.Panel;

public class Teclado implements KeyListener{
    private Panel pan;
    public Teclado(Panel pan){
        this.pan = pan;
    }

    @Override
    public void keyTyped(KeyEvent ke) {
    }

    @Override
    public void keyPressed(KeyEvent ke) {
	    	switch(ke.getKeyCode()){
		        case KeyEvent.VK_W:
		        	pan.ObCaJu().obCaract().setArribJ(true);;
		            break;
		        case KeyEvent.VK_A:
		        	pan.ObCaJu().obCaract().setIzqJ(true);;
		            break;
		        case KeyEvent.VK_S:
		        	pan.ObCaJu().obCaract().setAbaJ(true);;
		            break;
		        case KeyEvent.VK_D:
		        	pan.ObCaJu().obCaract().setDerJ(true);;
		            break;
	        
	    }
    }
    
    @Override
    public void keyReleased(KeyEvent ke) {
	    	switch(ke.getKeyCode()){
	        case KeyEvent.VK_W:
	        	pan.ObCaJu().obCaract().setArribJ(false);;
	            break;
	        case KeyEvent.VK_A:
	        	pan.ObCaJu().obCaract().setIzqJ(false);;
	            break;
	        case KeyEvent.VK_S:
	        	pan.ObCaJu().obCaract().setAbaJ(false);;
	            break;
	        case KeyEvent.VK_D:
	        	pan.ObCaJu().obCaract().setDerJ(false);;
	            break;
	        
	    }
    }
    
}