package AJugador;
/*
 * En este apartado obtenemos la carga de cada una de las imagenes usadas, se creo un metodo a parte 
 * para que cada entidad u bloque pueda optar a esta caracteristica;
 */
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;

import LogicaComp.Juego;

public class CargaGuardado {
	public static final String SpriteJugM = "RunMujerD.png";
	public static final String IMGlvl = "Tilemap.png";
	public static final String lvl1 = "Lvl1.png";
	
	
	public static BufferedImage ObImages(String NomArchiv){
		 BufferedImage img = null; 
		 InputStream is = CargaGuardado.class.getResourceAsStream("/"+NomArchiv);
			try {
				img = ImageIO.read(is);
				
			}catch(IOException e) {
				e.printStackTrace();
			}finally{
				try{
					is.close();
				}catch(IOException e){
					e.printStackTrace();
				}
			}
			return img;
	}
	
	public static int[][] ObDatosLvl(){
		int[][] lvlD = new int[Juego.Tam_Alt][Juego.Tam_Anch];
		BufferedImage im = ObImages(lvl1);
		
		for(int c = 0;c < im.getHeight();c++)
			for(int f = 0;f < im.getWidth();f++){
				Color color = new Color(im.getRGB(f, c));
				int valor = color.getRed(); 
				if(valor >= 24){valor = 0;}
				lvlD[c][f] = valor;
				System.out.println("Tres: "+color);
				System.out.println("Valor: "+valor);
				System.out.println("Color Red: "+color.getRed());
				
			}
		return lvlD;
	}

}
