package AJugador;

public class AnimJug {
	
	public static class LadoMira{
		public static final int Izq = 0;
		public static final int Der = 1;
		public static final int Arrib = 2;
		public static final int Aba = 3;
		
	}
	
	public static class jugadora{
		public static final int Correr = 0;
		public static final int Quieto = 1;
		
		public static int ObAnJug(int anju){
			switch(anju){
			case Correr:
				return 4;
			case Quieto:
				return 4;
			default:
				return 1;
			}
		}
	}
}
