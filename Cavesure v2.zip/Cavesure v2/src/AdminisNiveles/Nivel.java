package AdminisNiveles;

public class Nivel {
	
	
	private int[][] lvlD;
	public Nivel(int [][] lvlD){
		this.lvlD = lvlD;
	}
	
	public int ObIndiceIm(int x, int y){
		return lvlD[y][x];
	}
}
