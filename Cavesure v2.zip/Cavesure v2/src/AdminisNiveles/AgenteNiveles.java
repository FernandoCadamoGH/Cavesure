package AdminisNiveles;

/*
 * En este apartado observamos como cargar los niveles con el metodo rgb, el uso de este metodo
 * es por medio de la obtencion de un valor entero a partir de color rojo ejemplo (0[R],255[G],255[B],255[Alpha])
 * y asi pintar con forme al tileset por medio de la obtencion del valor de este, este metodo se puede encontrar en
 * los juegos clasicos para una mejor creacion de niveles, al igual que los tileset y tilemap
 */

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import AJugador.CargaGuardado;
import LogicaComp.Juego;

public class AgenteNiveles {
	private Juego JU;
	private BufferedImage[] Imagenes;
	private Nivel nv1;
	
	public AgenteNiveles(Juego JU){
		this.JU = JU;
//		Imagenes = CargaGuardado.ObImages(CargaGuardado.IMGlvl);
		MeterImagenBlock();
		nv1 = new Nivel(CargaGuardado.ObDatosLvl());
	}
	
	private void MeterImagenBlock() {
		BufferedImage imgo = CargaGuardado.ObImages(CargaGuardado.IMGlvl);
		Imagenes = new BufferedImage[24];
		for(int c = 0; c < 4; c++){
			for(int f = 0; f < 6;f++){
				int indice = c*6 + f;
				Imagenes[indice] = imgo.getSubimage(f*32,c*32,32,32); 
			}
		}
	}

	public void pintado(Graphics g){
		for(int c=0;c < Juego.Tam_Alt;c++)
			for(int f=0; f<Juego.Tam_Anch;f++){
				int indice = nv1.ObIndiceIm(f, c);
				g.drawImage(Imagenes[indice],Juego.Tam_Tile*f,Juego.Tam_Tile*c,Juego.Tam_Tile,Juego.Tam_Tile,null);
			}
	}
	
	public void actualiza(){
		
	}

}
